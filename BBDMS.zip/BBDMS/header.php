<!DOCTYPE html>
<html lang="en">
    <head>
        <style>
        .nav h1 {
            font-size: 36px;
            color: #e74c3c;
            margin: 0;
            padding-right: 450px;
        }

        .nav h1 span {
            color: #3498db;
        }

        .nav {
            display: flex;
            align-items: center;
            background-color: #34495e;
            position: fixed;
            top: 0;
            width: 98%;
            height: 60px;
            padding-left: 20px;
            z-index: 1000;
            border-radius: 5px;
            margin-right: 20px;
        }


        .nav a {
            color: white;
            padding: 20px 20px;
            text-decoration: none;
            font-size: 17px;
            border-radius: 5px;
        }

        .nav a:hover {
            background-color: #1abc9c;
        }
        </style>
    </head>
    <boby>
        <div class="nav">
            <h1><span>BB</span>DMS</h1>
            <a href="index.php">Home</a>
            <a href="AboutUs.php">About Us</a>
            <a href="ContactUs.php">Contact Us</a>
            <a href="DonorList.php">Donor List</a>
            <a href="SearchDonor.php">Search Donor</a>
            <a href="#">Admin</a>
            <a href="#">Login</a>
        </div>
    </body>
</html>