<?php
include('includes/dbconnection.php');
if (isset($_POST['submit'])) {
    $fnm = $_POST['fname'];
    $num = $_POST['number'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $bg = $_POST['blood_group'];
    $dob = $_POST['date-of-birth'];
    $add = $_POST['address'];
    $dt = $_POST['date-time'];
    $state = $_POST['state'];
    $pass = $_POST['password'];

    $sql = "INSERT INTO blooddonars (fname, number, email, age, gender, blood_group, `date-of-birth`, address, `date-time`, state, password) VALUES ('$fnm', '$num', '$email', '$age', '$gender', '$bg', '$dob', '$add', '$dt', '$state', '$pass')";
    $query = mysqli_query($con, $sql);
    if ($query) {
        echo "<script>alert('Registration successful!');</script>";
        echo "<script>window.location.href='index.php'</script>";
    } else {
            echo "<script>alert('Something went wrong. Please try again.');</script>";
        }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBDMS | Registration Page</title>
    <style>
        /* Reset some default styles */
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            background-color: #f7f7f7;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        .container {
            max-width: 600px;
            width: 100%;
            padding: 2rem;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-bottom: 1rem;
            color: #ff4d4d;
            text-align: center;
        }

        label {
            display: block;
            margin-top: 1rem;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="password"],
        input[type="datetime-local"],
        input[type="date"],
        textarea,
        select {
            width: 100%;
            padding: 0.5rem;
            margin-top: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            display: block;
            width: 100%;
            padding: 0.7rem;
            margin-top: 1.5rem;
            background: #ff4d4d;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #ff6666;
        }

        .back-button {
            background: #4d4dff;
            margin-top: 1rem;
        }

        .back-button:hover {
            background: #6666ff;
        }

        .error-message {
            color: red;
            margin-top: 1rem;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Registration</h2>
        <form id="registration-form" method="post">
            <label for="full-name">Full Name</label>
            <input type="text" id="full-name" name="fname" required>

            <label for="number">Number</label>
            <input type="text" id="number" name="number" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="age">Age</label>
            <input type="number" id="age" name="age" required>

            <label for="gender">Gender</label>
            <select id="gender" name="gender" required>
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <label for="bloodgroup">Blood Group</label>
            <select id="bloodgroup" name="blood_group" required>
                <option value="">Select Blood Group</option>
                <?php $sql = "SELECT * FROM `blood-group`";
                    $result = mysqli_query($con, $sql);
                    while ($data = mysqli_fetch_assoc($result)) {
                        $id = $data['id'];
                ?>
                <option value="<?php echo $data['bloodgroup']; ?>"><?php echo $data['bloodgroup']; ?></option>
                <?php }
					?>
            </select>

            <label for="dob">Date of Birth</label>
            <input type="date" id="dob" name="date-of-birth" required>

            <label for="address">Address</label>
            <textarea id="address" name="address" rows="3" required></textarea>

            <label for="registration-datetime">Registration Date-Time</label>
            <input type="datetime-local" id="registration-datetime" name="date-time" required readonly>

            <label for="state">State</label>
            <input type="text" id="state" name="state" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <button type="submit" name="submit">Register</button>
            <button type="button" class="back-button" onclick="goHome()">Back to Home</button>

            <p id="error-message" class="error-message"></p>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            // Set current date-time for registration field
            var now = new Date();
            var formattedDateTime = now.toISOString().slice(0, 16);
            document.getElementById('registration-datetime').value = formattedDateTime;
        });

        function goHome() {
            window.location.href = 'index.php';
        }
    </script>
</body>

</html>