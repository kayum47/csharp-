<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    .footer {
      text-align: center;
      padding: 10px;
      background-color: #34495e;
      color: white;
      position: relative;
      margin-top: 1px;
    }

    .div2 {
      width: 30%;
      display: inline-table;
      color: white;
      padding-left: 30px;
      text-align: left;
      
    }

    .div1 {
      background-color: #34495e;
      font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
      font-size: 17px;
    }

    .span1 {

      color: red;
    }

    .ul {
      list-style-type: none;

    }
    .b{
      border-radius: 5px;
    }

    .ul a {
      color: white;
      padding: 20px 20px;
      text-decoration: none;
      font-size: 17px;
      border-radius: 5px;
    }

    .ul li i {
      margin-right: 10px;
      color: red;
    }
  </style>
</head>

<body>
  <div class="div1 b">
    <div class="div2">
      <h1><span class="span1">Blood Bank & </span>Donor Management System</h1>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem
        aperiam,
        eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
    </div>
    <div class="div2 div3" style="padding-left: 50px;">
      <h2>Address</h2>
      <ul class="ul">
        <li><i class="fas fa-map-marker-alt"></i>Test Demo .</li>
        <li><i class="fas fa-phone-alt"></i>9638527410</li>
        <li><i class="fas fa-envelope"></i>Test@123gmail.com</li>
      </ul>
    </div>

    <div class="div2 div3">
      <h2>Quick Links</h2>
      <ul class="ul">
        <li><a href="#">Home</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="#">Contact Us</a></li>
      </ul>
    </div>
  </div>
  <div class="footer b">
    &copy; Blood Bank Donor Management System
  </div>
</body>

</html>