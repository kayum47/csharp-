<?php
session_start();
include('includes/dbconnection.php');
// Check if the form is submitted
if (isset($_POST['submit'])) {
    $unm = $_POST['UserName'];
	$pwd = $_POST['Password'];
	$sql = "SELECT * FROM `admin` WHERE `UserName`='$unm' AND `Password`='$pwd'";
	$result = mysqli_query($con,$sql);
	$data = mysqli_fetch_assoc($result);
	$count = mysqli_num_rows($result);

	if($count > 0)
	{
		session_start();
		$_SESSION['alogin']=$data['id'];
		/*$_SESSION['UserName']=$data['UserName'];*/
		header("location:Dashboard.php");
	}
	else
	{
		echo "<script>alert('Check Your Username & Password!');</script>";
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin login </title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: aliceblue;
        }

        .login-container {
            background-color: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.8);
            text-align: center;
            width: 300px;
        }

        .h1 {
            text-align: left;
            font-size: 30px;
            font-family: 'Times New Roman', Times, serif;
        }

        .input-group {
            margin-bottom: 15px;
            text-align: left;
        }

        label {
            font-size: 14px;
            color: #555;
            margin-bottom: 5px;
            display: block;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .login-button {
            width: 100%;
            padding: 10px;
            background-color: #3a8dff;
            background-image: linear-gradient(to right, #3a8dff, #764ba2);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }

        .login-button:hover {
            background-image: linear-gradient(to right, #3a8dff, #5a6bbf);
        }

        .link {
            display: block;
            margin-top: 15px;
            font-size: 15px;
            color: #3a8dff;
            text-decoration: none;
        }

        .link:hover {
            text-decoration: underline;
        }
        .back-button {
            background: #4d4dff;
            margin-top: 1rem;
            margin-left: 75px;
        }

        .back-button:hover {
            background: #6666ff;
        }
        button {
            display: block;
            width: 50%;
            padding: 0.7rem;
            margin-top: 1.5rem;
            background: #ff4d4d;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            
        }

        button:hover {
            background: #ff6666;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h1 class="h1">Welcome</h1>
        <form id="loginForm" method="POST">
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="UserName" placeholder="Enter Username" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="Password" placeholder="Enter Password" required>
            </div>
            <button type="submit" class="login-button" name="submit">Login</button>
        </form>
        <a href="forgot-password.php" class="link">Forgot Password?</a>
        <button type="button" class="back-button" onclick="goHome()">Back to Home</button>
    </div>
    <script>
        function goHome() {
            window.location.href = '../index.php';
        }
    </script>
</body>

</html>