<?php include('includes/dbconnection.php');
$sql = "SELECT * FROM `blood-group`";
$result = mysqli_query($con, $sql);

if (isset($_POST['delete'])) {
    $id = intval($_POST['id']);
    $delete = "DELETE FROM `blood-group` WHERE `id`=$id";
    $result = mysqli_query($con, $delete);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title> Admin | Manage Blood Groups</title>
    <style>
        /* styles.css */
        body {
            /*font-family: Arial, sans-serif;*/
            background-color: #f4f4f4;
        }

        .container {
            margin: 30px 20px 10px 280px;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-bottom: 20px;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #f9f9f9;
            font-weight: bold;
        }

        td button.delete-btn {
            background-color: #ff4d4d;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        td button.delete-btn:hover {
            background-color: #e60000;
        }
    </style>
    <script>
        function confirmDelete() {
            return confirm('Are you sure you want to delete this record?');
        }
    </script>
</head>

<body>
    <?php
    include('header.php');
    include('sidebar.php');
    ?>
    <div class="container">
        <h2>Manage Blood Groups</h2>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Blood Groups</th>
                        <th>Creation Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($data = mysqli_fetch_assoc($result)) {
                        $id = $data['id'];
                    ?>
                        <tr>
                            <td><?php echo $data['id']; ?></td>
                            <td><?php echo $data['bloodgroup']; ?></td>
                            <td><?php echo $data['creation_date']; ?></td>
                            <td>
                                <form method="POST" style="display:inline;" onsubmit="return confirmDelete();">
                                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                                    <button type="submit" class="delete-btn" name="delete">✖</button>
                                </form>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>