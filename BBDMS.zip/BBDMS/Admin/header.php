<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <style>
        body {
            display: block;
            margin: 0;
        }

        /* General Branding and Navigation Styling */
        .brand {
            background-color: black;
            padding: 2px 36px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #fff;
            position: fixed; /* Makes the navbar fixed */
            top: 0; /* Positions it at the top */
            left: 0;
            right: 0;
            z-index: 1000; /* Ensures it stays above other content */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Add padding to the body to avoid content being hidden behind the navbar */
        body {
            padding-top: 50px; /* Adjust according to the navbar height */
        }

        /* Profile Navigation */
        .ts-profile-nav {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            background-color: black;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .ts-profile-nav li {
            position: relative;
        }

        .ts-profile-nav li a {
            display: flex;
            align-items: center;
            padding: 8px 26px;
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s ease;
        }

        .ts-profile-nav li a:hover {
            color: #fff;
            background-color: red;
        }

        .ts-profile-nav .ts-avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 8px;
        }

        .ts-profile-nav .ts-account ul {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background-color: black;
            list-style: none;
            margin: 0;
            padding: 0;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }

        .ts-profile-nav .ts-account ul li {
            border-bottom: 1px solid #2c3e50;
        }

        .ts-profile-nav .ts-account ul li a {
            color: #ecf0f1;
            padding: 10px;
            display: block;
            text-decoration: none;
        }

        .ts-profile-nav .ts-account ul li a:hover {
            background-color: red;
            color: #fff;
        }

        /* Dropdown Menu Visibility */
        .ts-profile-nav .ts-account:hover ul {
            display: block;
        }

        /* Responsive Styling */
        @media (max-width: 768px) {
            .brand {
                flex-wrap: wrap;
                padding: 10px;
            }

            .menu-btn {
                display: block;
            }

            .ts-profile-nav {
                flex-direction: column;
                display: none;
                width: 100%;
                background-color: #2c3e50;
            }

            .ts-profile-nav li {
                width: 100%;
                text-align: left;
            }

            .ts-profile-nav.ts-account ul {
                position: relative;
                top: 0;
                background-color: #2c3e50;
            }
        }

        /* Show Profile Navigation on Click */
        .menu-btn.active+.ts-profile-nav,
        .ts-profile-nav.active {
            display: flex;
        }
    </style>
</head>

<body>
    <div class="brand">
        <p style="font-size: 20px; padding-top:1px; color:#fff">BloodBank & Donor Management System</p>

        <ul class="ts-profile-nav">
            <li class="ts-account">
                <a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
                <ul>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </div>
</body>

</html>
