<?php
session_start(); // Start session to store messages
include('includes/dbconnection.php');
    if (isset($_POST['update'])) {
        $add = $_POST['Address'];
        $email = $_POST['Email'];
        $num = $_POST['Number'];
        
        $updt = "update contactusinfo set `Address` ='$add',`Email` ='$email',`Number` ='$num'";
        $result = mysqli_query($con, $updt);
        if ($result) {
            $_SESSION['msg'] = "Blood Group Created successfully";
        } else {
            $_SESSION['error'] = "Something went wrong. Please try again";
        }
    
        // Redirect to the same page to avoid form resubmission
        header("Location: update-contactusinfo.php");
        exit(); // Ensure no further code is executed after the redirect
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Update Contact Info</title>
    <style>
        body {
            background-color: #f4f4f4;
            margin: 0;
        }

        .container {
            margin: 30px 20px 0px 280px;
            /*width: 80%;*/
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        .form-container {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }

        .form-group {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .form-group label {
            flex: 1;
            font-weight: bold;
            text-align: right;
            padding-right: 10px;
        }

        .form-group input[type="text"],
        .form-group textarea {
            flex: 2;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ddd;
            font-size: 14px;
            margin-bottom: 10px;
        }

        textarea {
            resize: vertical;
            height: 60px;
        }

        .update-btn {
            background-color: #3d6e99;
            color: white;
            border: none;
            margin: 10px auto;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            display: block;
        }

        .update-btn:hover {
            background-color: #2a4e73;
        }

        .errorWrap {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }

        .succWrap {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
    </style>
</head>
<body>
<?php
    include('header.php');
    include('sidebar.php');
    ?>
    <div class="container">
        <h2>Update Contact Info</h2>
        <div class="form-container">
            <form method="POST">
            <?php
                 // Start the session to use session variables
                if (isset($_SESSION['error'])) { ?>
                    <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($_SESSION['error']); ?></div>
                    <?php unset($_SESSION['error']); // Clear the message after displaying it
                } else if (isset($_SESSION['msg'])) { ?>
                    <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($_SESSION['msg']); ?></div>
                    <?php unset($_SESSION['msg']); // Clear the message after displaying it
                } ?>
                <?php
                $sql = "SELECT * FROM `contactusinfo` ";
                $result = mysqli_query($con, $sql);
                while ($data = mysqli_fetch_assoc($result)) {
                    $id = $data['id'];
                ?>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address" name="Address"  required><?php echo $data['Address']; ?></textarea>
                </div>
                <div class="form-group">
                    <label for="contact">Contact Number</label>
                    <input type="text" id="contact" name="Number" value="<?php echo $data['Number']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="text" id="email" name="Email" value="<?php echo $data['Email']; ?>" required>
                </div>
                <?php
                }
                ?>
                <button type="submit" class="update-btn" name="update">Update</button>
            </form>
        </div>
    </div>
</body>
</html>
