<html>
    <head>

    </head>
    <body>
    <?php include("header.php")?>
    <?php include("footer.php")?>
    </body>
</html>