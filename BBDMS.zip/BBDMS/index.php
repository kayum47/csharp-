<!DOCTYPE html>
<html>

<head>
    <title>Blood Bank & Donor Management System</title>
    <style>
        .carousel {
            position: relative;
            max-width: 100%;
            overflow: hidden;
            border: 1px solid #ddd;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 60px auto 0;
            /* Adjusted margin to avoid overlap with navbar */
        }

        .slides {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }

        .slide {
            min-width: 100%;
            box-sizing: border-box;
        }

        .slide img {
            width: 100%;
            display: block;
        }

        .prev,
        .next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            z-index: 10;
        }

        .prev {
            left: 10px;
        }

        .next {
            right: 10px;
        }
    </style>
    <script>
        let currentIndex = 0;

        function showSlide(index) {
            const slides = document.querySelector('.slides');
            const totalSlides = slides.children.length;

            if (index >= totalSlides) {
                currentIndex = 0;
            } else if (index < 0) {
                currentIndex = totalSlides - 1;
            } else {
                currentIndex = index;
            }

            const offset = -currentIndex * 100;
            slides.style.transform = `translateX(${offset}%)`;
        }

        function moveSlide(step) {
            showSlide(currentIndex + step);
        }

        // Auto slide every 3 seconds
        setInterval(() => {
            moveSlide(1);
        }, 3000);
    </script>
</head>

<body>
    <?php include("header.php")?>
    <div class="carousel">
        <div class="slides">
            <div class="slide"><img src="images/banner1.jpg" alt="Image 1"></div>
            <div class="slide"><img src="images/banner2.jpg" alt="Image 2"></div>
            <div class="slide"><img src="images/banner3.jpg" alt="Image 3"></div>
        </div>
        <button class="prev" onclick="moveSlide(-1)">&#10094;</button>
        <button class="next" onclick="moveSlide(1)">&#10095;</button>
    </div>
    <?php include("footer.php")?>
</body>

</html>