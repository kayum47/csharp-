﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data.Sql;


namespace empp1
{
    class config
    {
        public static SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|Emplogin.mdf;Integrated Security=True;User Instance=True");
        public static int menuitem = 0;
    }
}
