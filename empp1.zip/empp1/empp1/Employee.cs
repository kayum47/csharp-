﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace empp1
{
    public partial class Employee : Form
    {
        string id = string.Empty;
        int tr = 0;
        int rp = 0;

        public Employee()
        {
            InitializeComponent();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
            }
                return base.ProcessCmdKey(ref msg, keyData);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = string.Empty;
            string msg = string.Empty;
            if (button1.Text == "&Add Employee")
            {
                if (comboBox1.Text != "Select department" && textBox2.Text != "" && textBox3.Text != "")
                {
                    sql = "insert into empinfo values('" + id + "','" + textBox2.Text + "','" + comboBox1.Text + "','" + dateTimePicker1.Text + "','" + textBox3.Text + "')";
                    msg = "Insert!";
                }
            }
            else if (button1.Text == "&Update Employee")
            {
                if (comboBox1.Text != "Select Department" && textBox2.Text != "" && textBox3.Text != "")
                {
                    sql = "update empinfo set empname='" + textBox2.Text + "',empdept='" + comboBox1.Text + "',joingdate='" + dateTimePicker1.Text + "',salary='" + textBox3.Text + "' where id='" + textBox1.Text + "'";
                    msg = "Update!";
                    rp = 0;
                }
            }
            else if (button1.Text == "&Delete Employee")
            {
                sql = "delete from empinfo where id='" + textBox1.Text + "'";
                msg = "Delete!";
                rp = 0;
            }
            SqlDataAdapter da = new SqlDataAdapter(sql, config.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            MessageBox.Show(msg, "App", MessageBoxButtons.OK, MessageBoxIcon.Information);
            getdata();

            if (button1.Text == "&Add Employee" || tr < 0)
            {
                textBox2.Text = textBox3.Text = string.Empty;
                comboBox1.Text = "Select Department";
                dateTimePicker1.Text = DateTime.Now.ToString();
                textBox2.Focus();
                if (button1.Text == "&Delete Employee" || button1.Text == "&Update Employee")
                {
                    button1.Enabled = false;
                }
            }
        }

        private void Employee_Load(object sender, EventArgs e)
        {
             if (config.menuitem == 0)
            {
                button2.Visible = false;
                button3.Visible = false;
                button4.Visible = false;
                button5.Visible = false;
            }
            else if (config.menuitem == 1)
            {
                button1.Visible = false;
                button1.Text = "";
            }
            else if (config.menuitem == 3)
            {
                button1.Text = "&Update Employee";
            }
            else if (config.menuitem == 4)
            {
                button1.Text = "&Delete Employee";
            }
            getdata();
        }
        private void getdata()
        {
            dateTimePicker1.MaxDate = DateTime.Now;
            string sql = "select * from empinfo";
            SqlDataAdapter da = new SqlDataAdapter(sql, config.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            tr = dt.Rows.Count - 1;
            if (config.menuitem == 0)
            {
                if (dt.Rows.Count == 0)
                {
                    id = "EMP0001";
                    textBox1.Text = id;
                }
                else
                {
                    tr = dt.Rows.Count - 1;
                    string tempid = dt.Rows[tr][0].ToString();
                    string getid = tempid.Substring(3);
                    int newtempid = Convert.ToInt32(getid) + 1;
                    textBox1.Text = "EMP" + newtempid.ToString("0000");
                    id = textBox1.Text;
                }
            }
            else
            {
                if (dt.Rows.Count > 0)
                {
                    textBox1.Text = dt.Rows[rp][0].ToString();
                    textBox2.Text = dt.Rows[rp][1].ToString();
                    comboBox1.Text = dt.Rows[rp][2].ToString();
                    dateTimePicker1.Text = dt.Rows[rp][3].ToString();
                    textBox3.Text = dt.Rows[rp][4].ToString();
                }
                else
                {
                    if (button1.Text != "&Add Employee")
                    {
                        button2.Enabled = false;
                        button3.Enabled = false;
                        button4.Enabled = false;
                        button5.Enabled = false;
                        button1.Enabled = false;
                    }
                }
            }
        }
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (tr > 0)
            {
                rp = 0;
                getdata();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (rp < tr)
            {
                rp++;
                getdata();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (rp > 0)
            {
                rp--;
                getdata();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (tr > 0)
            {
                rp = tr;
                getdata();
            }
        }  
    }
}
