﻿namespace employee
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addemp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.empid = new System.Windows.Forms.TextBox();
            this.empdept = new System.Windows.Forms.TextBox();
            this.empname = new System.Windows.Forms.TextBox();
            this.salary = new System.Windows.Forms.TextBox();
            this.joindate = new System.Windows.Forms.DateTimePicker();
            this.update = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.show = new System.Windows.Forms.Button();
            this.find = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.textsearch = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // addemp
            // 
            this.addemp.Location = new System.Drawing.Point(33, 217);
            this.addemp.Name = "addemp";
            this.addemp.Size = new System.Drawing.Size(47, 23);
            this.addemp.TabIndex = 0;
            this.addemp.Text = "Add";
            this.addemp.UseVisualStyleBackColor = true;
            this.addemp.Click += new System.EventHandler(this.addemp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Emp Id";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Emp Dept";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Emp Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Join Date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Salary";
            // 
            // empid
            // 
            this.empid.Location = new System.Drawing.Point(134, 28);
            this.empid.Name = "empid";
            this.empid.Size = new System.Drawing.Size(198, 22);
            this.empid.TabIndex = 6;
            // 
            // empdept
            // 
            this.empdept.Location = new System.Drawing.Point(134, 62);
            this.empdept.Name = "empdept";
            this.empdept.Size = new System.Drawing.Size(198, 22);
            this.empdept.TabIndex = 7;
            // 
            // empname
            // 
            this.empname.Location = new System.Drawing.Point(134, 104);
            this.empname.Name = "empname";
            this.empname.Size = new System.Drawing.Size(198, 22);
            this.empname.TabIndex = 8;
            // 
            // salary
            // 
            this.salary.Location = new System.Drawing.Point(134, 174);
            this.salary.Name = "salary";
            this.salary.Size = new System.Drawing.Size(198, 22);
            this.salary.TabIndex = 9;
            // 
            // joindate
            // 
            this.joindate.Location = new System.Drawing.Point(134, 140);
            this.joindate.Name = "joindate";
            this.joindate.Size = new System.Drawing.Size(198, 22);
            this.joindate.TabIndex = 10;
            // 
            // update
            // 
            this.update.Location = new System.Drawing.Point(95, 217);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(75, 23);
            this.update.TabIndex = 11;
            this.update.Text = "Update";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(394, 62);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(383, 175);
            this.dataGridView1.TabIndex = 12;
            // 
            // show
            // 
            this.show.Location = new System.Drawing.Point(176, 217);
            this.show.Name = "show";
            this.show.Size = new System.Drawing.Size(75, 23);
            this.show.TabIndex = 13;
            this.show.Text = "Show";
            this.show.UseVisualStyleBackColor = true;
            this.show.Click += new System.EventHandler(this.show_Click);
            // 
            // find
            // 
            this.find.Location = new System.Drawing.Point(691, 21);
            this.find.Name = "find";
            this.find.Size = new System.Drawing.Size(75, 23);
            this.find.TabIndex = 14;
            this.find.Text = "find";
            this.find.UseVisualStyleBackColor = true;
            this.find.Click += new System.EventHandler(this.find_Click);
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(257, 217);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(75, 23);
            this.delete.TabIndex = 15;
            this.delete.Text = "delete";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // textsearch
            // 
            this.textsearch.Location = new System.Drawing.Point(493, 22);
            this.textsearch.Name = "textsearch";
            this.textsearch.Size = new System.Drawing.Size(181, 22);
            this.textsearch.TabIndex = 16;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 264);
            this.Controls.Add(this.textsearch);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.find);
            this.Controls.Add(this.show);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.update);
            this.Controls.Add(this.joindate);
            this.Controls.Add(this.salary);
            this.Controls.Add(this.empname);
            this.Controls.Add(this.empdept);
            this.Controls.Add(this.empid);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.addemp);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addemp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox empid;
        private System.Windows.Forms.TextBox empdept;
        private System.Windows.Forms.TextBox empname;
        private System.Windows.Forms.TextBox salary;
        private System.Windows.Forms.DateTimePicker joindate;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button show;
        private System.Windows.Forms.Button find;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.TextBox textsearch;

    }
}