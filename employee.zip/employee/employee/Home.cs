﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
namespace employee
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void addemp_Click(object sender, EventArgs e)
        {

            Class1.cn.Open();
            SqlCommand cmd = new SqlCommand("insert into emp_details values('" + empid.Text + "', '" + empdept.Text + "', '" + empname.Text + "', '" + joindate.Text + "', '" + salary.Text + "')", Class1.cn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Inserted Successfully.");
            Class1.cn.Close();
            displaydata();
        }

        private void cleardata()
        {
            empid.Clear();
            empdept.Clear();
            empname.Clear();
            salary.Clear();
        }

        private void update_Click(object sender, EventArgs e)
        {
            Class1.cn.Open();
            SqlCommand cmd = Class1.cn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update emp_details set emp_dept='" + empdept.Text + "',emp_name='" + empname.Text + "',join_date='" + joindate.Text.ToString() + "',salary='" + salary.Text.ToString() + "' where emp_id='" + empid.Text.ToString() + "' ";
            cmd.ExecuteNonQuery();
            Class1.cn.Close();
            displaydata();
            cleardata();
        }

        private void show_Click(object sender, EventArgs e)
        {
            displaydata();
        }
        private void displaydata()
        {
            Class1.cn.Open();
            SqlCommand cmd = Class1.cn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from emp_details";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            Class1.cn.Close();
        }

       

        private void find_Click(object sender, EventArgs e)
        {
              Class1.cn.Open();
                SqlCommand cmd = Class1.cn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from emp_details where emp_id='" + textsearch.Text + "'";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                empid.Text = dt.ToString();
                empdept.Text = dt.ToString();
                empname.Text = dt.ToString();
                joindate.Text = dt.ToString();
                dataGridView1.DataSource = dt;
                Class1.cn.Close();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            string query = "delete emp_details where emp_id='{empid.Text.ToString()}'";
            cmd.CommandText = query;
            Class1.cn.Open();
            cmd.ExecuteNonQuery();
            dataGridView1.DataSource = query;
            cleardata();
            Class1.cn.Close();
            displaydata();
        }



    }
}
