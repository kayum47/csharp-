﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace employee
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void login_Click(object sender, EventArgs e)
        {
            string sql = "select * from admin_login where unm='" + textBox1.Text + "' and pwd='" + textBox2.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                Home h = new Home();
                h.Show();
                this.Hide();
            }
            else {
                MessageBox.Show("Invalid","database",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                clear();
            }
        }

        private void clear() {
            textBox1.Text = textBox2.Text = "";
            textBox1.Focus();
        }

    }
}
