﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace student
{
    public partial class Form1 : Form
    {
        string zipv = "N";
        string mov = "N";
        string aav = "N";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                Application.Exit();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!Char.IsDigit(e.KeyChar))
            {
                e.Handled=true;
            }
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox1.Text.Length < 12)
            {
                textBox1.ForeColor = Color.Red;
            }
            else
            {
                string sql = "select aadhar from studinfo where aadhar='" + textBox1.Text + "'";
                SqlDataAdapter da = new SqlDataAdapter(sql, config.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count == 1)
                {
                    textBox1.ForeColor = Color.Red;
                    aav = "N";
                }
                else
                {
                    textBox1.ForeColor = Color.Green;
                    aav = "Y";
                }
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox3.Text.Length < 10)
            {
                textBox3.ForeColor = Color.Red;
            }
            else
            {
                textBox3.ForeColor = Color.Green;
                mov = "Y";
            }
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox7_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox7.Text.Length < 6)
            {
                textBox7.ForeColor = Color.Red;
            }
            else
            {
                textBox7.ForeColor = Color.Green;
                zipv = "Y";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string gender = string.Empty;
            if (zipv == "Y" && mov == "Y" && aav == "Y")
            {
                if (radioButton1.Checked == true)
                {
                    gender = "M";
                }
                else if (radioButton2.Checked == true)
                {
                    gender = "F";
                }
                else {
                    gender = "O";
                }
                string sql = "insert into studinfo values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + comboBox1.Text + "','" + gender + "','" + textBox6.Text + "','" + textBox7.Text + "') ";
                SqlDataAdapter da = new SqlDataAdapter(sql, config.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
            }
        }
    }
}
