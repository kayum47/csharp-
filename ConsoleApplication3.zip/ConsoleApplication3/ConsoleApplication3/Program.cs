﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace ConsoleApplication3
{
    public delegate void DelEvenHandler();

    internal class Program : Form
    {
        public event DelEvenHandler add;
        public Program()
        {
            Button btn = new Button();
            btn.Parent = this;
            btn.Text = "Click Me !";
            btn.Location = new Point(100, 100);
            btn.Click+=new EventHandler(onClick);
        }
        public void onClick(object sender,EventArgs e)
        {
            MessageBox.Show("Click !");
        }
        static void Main(string[] args)
        {
            Application.Run(new Program());
            Console.Read();
        }
    }
}
