<?php
session_start();
$con=mysqli_connect('localhost','root','','leave_management_system');
?>