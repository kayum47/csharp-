﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Arithmatic
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your Choice From The Menu");
            Console.WriteLine("Option A : Addition");
            Console.WriteLine("Option B : Substraction");
            Console.WriteLine("Option C : Multiplication");
            Console.WriteLine("Option D : Division");
            char c = Convert.ToChar(Console.ReadLine());
            Console.Write("Enter value 1 : ");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter value 2 : ");
            int m = Convert.ToInt32(Console.ReadLine());
            int w = n + m;
            int x = n - m;
            int y = n * m;
            int z= n / m;
            switch (c)
            {
                case 'a':
                case 'A':
                    Console.WriteLine("A + B = " + w);
                    break;

                case 'b':
                case 'B':
                    Console.WriteLine("A - B = " + x);
                    break;

                case 'c':
                case 'C':
                    Console.WriteLine("A * B = " + y);
                    break;

                case 'd':
                case 'D':
                    Console.WriteLine("A / B = " + z);
                    break;

                default:
                    Console.WriteLine("Enter Valid Choice!");
                    break;
            }
            Console.Read();
        }
    }
}
