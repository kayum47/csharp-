﻿namespace game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label9;
            System.Windows.Forms.Label label10;
            System.Windows.Forms.Label label11;
            System.Windows.Forms.Label label12;
            System.Windows.Forms.Label label13;
            System.Windows.Forms.Label label14;
            System.Windows.Forms.Label label15;
            System.Windows.Forms.Label label16;
            System.Windows.Forms.Label label17;
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            label16 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.Dock = System.Windows.Forms.DockStyle.Fill;
            label1.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label1.Location = new System.Drawing.Point(6, 3);
            label1.Name = "label1";
            label1.Padding = new System.Windows.Forms.Padding(20);
            label1.Size = new System.Drawing.Size(112, 138);
            label1.TabIndex = 0;
            label1.Text = "label1";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = System.Windows.Forms.DockStyle.Fill;
            label2.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label2.Location = new System.Drawing.Point(127, 3);
            label2.Name = "label2";
            label2.Padding = new System.Windows.Forms.Padding(20);
            label2.Size = new System.Drawing.Size(112, 138);
            label2.TabIndex = 1;
            label2.Text = "label2";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label2.Click += new System.EventHandler(this.label1_Click);
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = System.Windows.Forms.DockStyle.Fill;
            label3.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label3.Location = new System.Drawing.Point(248, 3);
            label3.Name = "label3";
            label3.Padding = new System.Windows.Forms.Padding(20);
            label3.Size = new System.Drawing.Size(112, 138);
            label3.TabIndex = 2;
            label3.Text = "label3";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label3.Click += new System.EventHandler(this.label1_Click);
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = System.Windows.Forms.DockStyle.Fill;
            label4.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label4.Location = new System.Drawing.Point(369, 3);
            label4.Name = "label4";
            label4.Padding = new System.Windows.Forms.Padding(20);
            label4.Size = new System.Drawing.Size(112, 138);
            label4.TabIndex = 3;
            label4.Text = "label4";
            label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label4.Click += new System.EventHandler(this.label1_Click);
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Dock = System.Windows.Forms.DockStyle.Fill;
            label5.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label5.Location = new System.Drawing.Point(6, 144);
            label5.Name = "label5";
            label5.Padding = new System.Windows.Forms.Padding(20);
            label5.Size = new System.Drawing.Size(112, 138);
            label5.TabIndex = 4;
            label5.Text = "label5";
            label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label5.Click += new System.EventHandler(this.label1_Click);
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Dock = System.Windows.Forms.DockStyle.Fill;
            label6.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label6.Location = new System.Drawing.Point(127, 144);
            label6.Name = "label6";
            label6.Padding = new System.Windows.Forms.Padding(20);
            label6.Size = new System.Drawing.Size(112, 138);
            label6.TabIndex = 5;
            label6.Text = "label6";
            label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label6.Click += new System.EventHandler(this.label1_Click);
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Dock = System.Windows.Forms.DockStyle.Fill;
            label7.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label7.Location = new System.Drawing.Point(248, 144);
            label7.Name = "label7";
            label7.Padding = new System.Windows.Forms.Padding(20);
            label7.Size = new System.Drawing.Size(112, 138);
            label7.TabIndex = 6;
            label7.Text = "label7";
            label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label7.Click += new System.EventHandler(this.label1_Click);
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Dock = System.Windows.Forms.DockStyle.Fill;
            label8.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label8.Location = new System.Drawing.Point(369, 144);
            label8.Name = "label8";
            label8.Padding = new System.Windows.Forms.Padding(20);
            label8.Size = new System.Drawing.Size(112, 138);
            label8.TabIndex = 7;
            label8.Text = "label8";
            label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label8.Click += new System.EventHandler(this.label1_Click);
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Dock = System.Windows.Forms.DockStyle.Fill;
            label9.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label9.Location = new System.Drawing.Point(6, 285);
            label9.Name = "label9";
            label9.Padding = new System.Windows.Forms.Padding(20);
            label9.Size = new System.Drawing.Size(112, 138);
            label9.TabIndex = 8;
            label9.Text = "label9";
            label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label9.Click += new System.EventHandler(this.label1_Click);
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Dock = System.Windows.Forms.DockStyle.Fill;
            label10.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label10.Location = new System.Drawing.Point(127, 285);
            label10.Name = "label10";
            label10.Padding = new System.Windows.Forms.Padding(20);
            label10.Size = new System.Drawing.Size(112, 138);
            label10.TabIndex = 9;
            label10.Text = "label10";
            label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label10.Click += new System.EventHandler(this.label1_Click);
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Dock = System.Windows.Forms.DockStyle.Fill;
            label11.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label11.Location = new System.Drawing.Point(248, 285);
            label11.Name = "label11";
            label11.Padding = new System.Windows.Forms.Padding(20);
            label11.Size = new System.Drawing.Size(112, 138);
            label11.TabIndex = 10;
            label11.Text = "label11";
            label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label11.Click += new System.EventHandler(this.label1_Click);
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Dock = System.Windows.Forms.DockStyle.Fill;
            label12.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label12.Location = new System.Drawing.Point(369, 285);
            label12.Name = "label12";
            label12.Padding = new System.Windows.Forms.Padding(20);
            label12.Size = new System.Drawing.Size(112, 138);
            label12.TabIndex = 11;
            label12.Text = "label12";
            label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label12.Click += new System.EventHandler(this.label1_Click);
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Dock = System.Windows.Forms.DockStyle.Fill;
            label13.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label13.Location = new System.Drawing.Point(6, 426);
            label13.Name = "label13";
            label13.Padding = new System.Windows.Forms.Padding(20);
            label13.Size = new System.Drawing.Size(112, 138);
            label13.TabIndex = 12;
            label13.Text = "label13";
            label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label13.Click += new System.EventHandler(this.label1_Click);
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Dock = System.Windows.Forms.DockStyle.Fill;
            label14.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label14.Location = new System.Drawing.Point(127, 426);
            label14.Name = "label14";
            label14.Padding = new System.Windows.Forms.Padding(20);
            label14.Size = new System.Drawing.Size(112, 138);
            label14.TabIndex = 13;
            label14.Text = "label14";
            label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label14.Click += new System.EventHandler(this.label1_Click);
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Dock = System.Windows.Forms.DockStyle.Fill;
            label15.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label15.Location = new System.Drawing.Point(248, 426);
            label15.Name = "label15";
            label15.Padding = new System.Windows.Forms.Padding(20);
            label15.Size = new System.Drawing.Size(112, 138);
            label15.TabIndex = 14;
            label15.Text = "label15";
            label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label15.Click += new System.EventHandler(this.label1_Click);
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Cursor = System.Windows.Forms.Cursors.IBeam;
            label16.Dock = System.Windows.Forms.DockStyle.Fill;
            label16.Font = new System.Drawing.Font("Webdings", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            label16.Location = new System.Drawing.Point(369, 426);
            label16.Name = "label16";
            label16.Padding = new System.Windows.Forms.Padding(20);
            label16.Size = new System.Drawing.Size(112, 138);
            label16.TabIndex = 15;
            label16.Text = "label16";
            label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label16.Click += new System.EventHandler(this.label1_Click);
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Dock = System.Windows.Forms.DockStyle.Fill;
            label17.Location = new System.Drawing.Point(490, 3);
            label17.Name = "label17";
            label17.Padding = new System.Windows.Forms.Padding(20);
            label17.Size = new System.Drawing.Size(112, 138);
            label17.TabIndex = 16;
            label17.Text = "label17";
            label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label17.Click += new System.EventHandler(this.label1_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetDouble;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Controls.Add(label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(label2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(label3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(label4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(label5, 0, 1);
            this.tableLayoutPanel1.Controls.Add(label6, 1, 1);
            this.tableLayoutPanel1.Controls.Add(label7, 2, 1);
            this.tableLayoutPanel1.Controls.Add(label8, 3, 1);
            this.tableLayoutPanel1.Controls.Add(label9, 0, 2);
            this.tableLayoutPanel1.Controls.Add(label10, 1, 2);
            this.tableLayoutPanel1.Controls.Add(label11, 2, 2);
            this.tableLayoutPanel1.Controls.Add(label12, 3, 2);
            this.tableLayoutPanel1.Controls.Add(label13, 0, 3);
            this.tableLayoutPanel1.Controls.Add(label14, 1, 3);
            this.tableLayoutPanel1.Controls.Add(label15, 2, 3);
            this.tableLayoutPanel1.Controls.Add(label16, 3, 3);
            this.tableLayoutPanel1.Controls.Add(label17, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.label18, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.label19, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.label20, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.label21, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label22, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label23, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.label24, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.label25, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.label26, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.label27, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.label28, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.label29, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.label30, 5, 4);
            this.tableLayoutPanel1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Webdings", 48F);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(734, 712);
            this.tableLayoutPanel1.TabIndex = 0;
            this.tableLayoutPanel1.Click += new System.EventHandler(this.label1_Click);
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Location = new System.Drawing.Point(490, 144);
            this.label18.Name = "label18";
            this.label18.Padding = new System.Windows.Forms.Padding(20);
            this.label18.Size = new System.Drawing.Size(112, 138);
            this.label18.TabIndex = 17;
            this.label18.Text = "label18";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label18.Click += new System.EventHandler(this.label1_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Location = new System.Drawing.Point(490, 285);
            this.label19.Name = "label19";
            this.label19.Padding = new System.Windows.Forms.Padding(20);
            this.label19.Size = new System.Drawing.Size(112, 138);
            this.label19.TabIndex = 18;
            this.label19.Text = "label19";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.Click += new System.EventHandler(this.label1_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Location = new System.Drawing.Point(490, 426);
            this.label20.Name = "label20";
            this.label20.Padding = new System.Windows.Forms.Padding(20);
            this.label20.Size = new System.Drawing.Size(112, 138);
            this.label20.TabIndex = 19;
            this.label20.Text = "label20";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.Click += new System.EventHandler(this.label1_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Location = new System.Drawing.Point(6, 567);
            this.label21.Name = "label21";
            this.label21.Padding = new System.Windows.Forms.Padding(20);
            this.label21.Size = new System.Drawing.Size(112, 142);
            this.label21.TabIndex = 20;
            this.label21.Text = "label21";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.Click += new System.EventHandler(this.label1_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Location = new System.Drawing.Point(127, 567);
            this.label22.Name = "label22";
            this.label22.Padding = new System.Windows.Forms.Padding(20);
            this.label22.Size = new System.Drawing.Size(112, 142);
            this.label22.TabIndex = 21;
            this.label22.Text = "label22";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label22.Click += new System.EventHandler(this.label1_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Location = new System.Drawing.Point(248, 567);
            this.label23.Name = "label23";
            this.label23.Padding = new System.Windows.Forms.Padding(20);
            this.label23.Size = new System.Drawing.Size(112, 142);
            this.label23.TabIndex = 22;
            this.label23.Text = "label23";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label23.Click += new System.EventHandler(this.label1_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Location = new System.Drawing.Point(369, 567);
            this.label24.Name = "label24";
            this.label24.Padding = new System.Windows.Forms.Padding(20);
            this.label24.Size = new System.Drawing.Size(112, 142);
            this.label24.TabIndex = 23;
            this.label24.Text = "label24";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label24.Click += new System.EventHandler(this.label1_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Location = new System.Drawing.Point(490, 567);
            this.label25.Name = "label25";
            this.label25.Padding = new System.Windows.Forms.Padding(20);
            this.label25.Size = new System.Drawing.Size(112, 142);
            this.label25.TabIndex = 24;
            this.label25.Text = "label25";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label25.Click += new System.EventHandler(this.label1_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Location = new System.Drawing.Point(611, 3);
            this.label26.Name = "label26";
            this.label26.Padding = new System.Windows.Forms.Padding(20);
            this.label26.Size = new System.Drawing.Size(117, 138);
            this.label26.TabIndex = 25;
            this.label26.Text = "label26";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label26.AutoSizeChanged += new System.EventHandler(this.label1_Click);
            this.label26.Click += new System.EventHandler(this.label1_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Location = new System.Drawing.Point(611, 144);
            this.label27.Name = "label27";
            this.label27.Padding = new System.Windows.Forms.Padding(20);
            this.label27.Size = new System.Drawing.Size(117, 138);
            this.label27.TabIndex = 26;
            this.label27.Text = "label27";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label27.AutoSizeChanged += new System.EventHandler(this.label1_Click);
            this.label27.Click += new System.EventHandler(this.label1_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Location = new System.Drawing.Point(611, 285);
            this.label28.Name = "label28";
            this.label28.Padding = new System.Windows.Forms.Padding(20);
            this.label28.Size = new System.Drawing.Size(117, 138);
            this.label28.TabIndex = 27;
            this.label28.Text = "label28";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label28.AutoSizeChanged += new System.EventHandler(this.label1_Click);
            this.label28.Click += new System.EventHandler(this.label1_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Location = new System.Drawing.Point(611, 426);
            this.label29.Name = "label29";
            this.label29.Padding = new System.Windows.Forms.Padding(20);
            this.label29.Size = new System.Drawing.Size(117, 138);
            this.label29.TabIndex = 28;
            this.label29.Text = "label29";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label29.AutoSizeChanged += new System.EventHandler(this.label1_Click);
            this.label29.Click += new System.EventHandler(this.label1_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Location = new System.Drawing.Point(611, 567);
            this.label30.Name = "label30";
            this.label30.Padding = new System.Windows.Forms.Padding(20);
            this.label30.Size = new System.Drawing.Size(117, 142);
            this.label30.TabIndex = 29;
            this.label30.Text = "label30";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.AutoSizeChanged += new System.EventHandler(this.label1_Click);
            this.label30.Click += new System.EventHandler(this.label1_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 712);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
    }
}

