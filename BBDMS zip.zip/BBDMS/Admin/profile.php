<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

    if (isset($_POST['update'])) {
        $anm = $_POST['AdminName'];
        $unm = $_POST['UserName'];
        $num = $_POST['MobileNumber'];
        $eml = $_POST['Email'];
        $updt = "update admin set `AdminName` ='$anm',`UserName` ='$unm',`MobileNumber` ='$num',`Email` ='$eml' ";
        $result = mysqli_query($con, $updt);

        if ($result) {
            $_SESSION['msg'] = "Blood Group Created successfully";
        } else {
            $_SESSION['error'] = "Something went wrong. Please try again";
        }
    
        // Redirect to the same page to avoid form resubmission
        header("Location: profile.php");
        exit(); // Ensure no further code is executed after the redirect
    }


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Contact Info</title>
    <style>
        /* Body Styling */
        body {
            background-color: #f4f4f4;
            margin: 0;
        }

        /* Container for the entire form */
        .container {
            margin: 30px 20px 0px 280px;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* Heading styling */
        h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        /* Inner container for the form fields */
        .form-container {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }

        /* Grouping form fields together */
        .form-group {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        /* Label styling */
        .form-group label {
            flex: 1;
            font-weight: bold;
            text-align: right;
            padding-right: 10px;
        }

        /* Input and textarea styling */
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group textarea {
            flex: 2;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ddd;
            font-size: 14px;
            margin: 0;
        }

        /* Specific textarea styling */
        textarea {
            resize: vertical;
            height: 60px;
        }

        /* Button styling */
        .form-button {
            text-align: center; /* Center align the button */
            margin-top: 20px;
        }

        .form-button button {
            background-color: #3d6e99;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        .form-button button:hover {
            background-color: #2a4e73;
        }

        /* Error and success message styling */
        .errorWrap {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }

        .succWrap {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
    </style>
</head>

<body>
    <?php
    include('header.php');
    include('sidebar.php');
    ?>
    <div class="container">
        <h2>Admin Profile</h2>
        <div class="form-container">
            <form method="POST">
            <?php
                 // Start the session to use session variables
                if (isset($_SESSION['error'])) { ?>
                    <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($_SESSION['error']); ?></div>
                    <?php unset($_SESSION['error']); // Clear the message after displaying it
                } else if (isset($_SESSION['msg'])) { ?>
                    <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($_SESSION['msg']); ?></div>
                    <?php unset($_SESSION['msg']); // Clear the message after displaying it
                } ?>
                <?php
                $uid=$_SESSION['alogin'];
                $sql = "SELECT * FROM `admin`";
                $result = mysqli_query($con, $sql);
                while ($data = mysqli_fetch_assoc($result)) {
                    $id = $data['id'];
                ?>
                <div class="form-group">
                    <label for="adminName">Admin Name</label>
                    <input type="text" id="adminName" name="AdminName" value="<?php echo $data['AdminName']; ?>" require>
                </div>
                <div class="form-group">
                    <label for="userName">User Name</label>
                    <input type="text" id="userName" name="UserName" value="<?php echo $data['UserName']; ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="contactNumber">Contact Number</label>
                    <input type="text" id="contactNumber" name="MobileNumber" value="<?php echo $data['MobileNumber']; ?>" require>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="Email" value="<?php echo $data['Email']; ?>" require>
                </div>
                <?php
                }
                ?>
                <div class="form-button">
                    <button type="submit" name="update">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>
