<?php
session_start(); // Start session to store messages
include('includes/dbconnection.php');

// Code for adding blood group
if (isset($_POST['submit'])) {
    $bloodgroup = $_POST['bloodgroup'];
    $sql = "INSERT INTO `blood-group` (`bloodgroup`) values('$bloodgroup')";
    $result = mysqli_query($con, $sql);
    
    if ($result) {
        $_SESSION['msg'] = "Blood Group Created successfully";
    } else {
        $_SESSION['error'] = "Something went wrong. Please try again";
    }

    // Redirect to the same page to avoid form resubmission
    header("Location: add-bloodgroup.php");
    exit(); // Ensure no further code is executed after the redirect
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Add Blood Group</title>
    <style>
        /* styles.css */
        body {
            background-color: #f4f4f4;
        }

        .container {
            margin: 20px 20px 0px 280px;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            margin-bottom: 20px;
        }

        .form-container {
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }

        .form-group {
            margin-bottom: 30px;
            display: flex;
            align-items: center;
        }

        label {
            flex: 1;
            font-weight: bold;
            text-align: right;
            padding-right: 10px;
        }

        input[type="text"] {
            flex: 2;
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }

        .submit-btn {
            background-color: #3d6e99;
            color: white;
            border: none;
            margin-left: 300px;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        .submit-btn:hover {
            background-color: #2a4e73;
        }

        .errorWrap {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }

        .succWrap {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
    </style>
</head>

<body>
    <?php
    include('header.php');
    include('sidebar.php');
    ?>
    <div class="container">
        <h2>Add Blood Group</h2>
        <div class="form-container">
            <form method="POST">
                <!-- Display success or error messages -->
                <?php
                 // Start the session to use session variables
                if (isset($_SESSION['error'])) { ?>
                    <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($_SESSION['error']); ?></div>
                    <?php unset($_SESSION['error']); // Clear the message after displaying it
                } else if (isset($_SESSION['msg'])) { ?>
                    <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($_SESSION['msg']); ?></div>
                    <?php unset($_SESSION['msg']); // Clear the message after displaying it
                } ?>
                
                <div class="form-group">
                    <label for="blood_group">Blood Group</label>
                    <input type="text" id="blood_group" name="bloodgroup" required>
                </div>
                <button type="submit" class="submit-btn" name="submit">Submit</button>
            </form>
        </div>
    </div>
</body>

</html>