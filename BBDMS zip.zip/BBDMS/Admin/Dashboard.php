<?php session_start();
error_reporting(0);
include('includes/dbconnection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        /* CSS Styles */
        body {

            background-color: #f5f5f5;

        }

        .container {
            margin: 30px 20px 0px 280px;
            /*width: 80%;*/
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .dashboard {
            font-family: Arial, sans-serif;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 40px;
            width: 98%;

        }

        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 10px;
            text-align: center;
            color: white;
            position: relative;
            height: 150px;
            /* Card height to accommodate button */
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            width: 100%;
            /* Ensure card takes full width of grid cell */
        }

        .card h2 {
            margin: 0;
            font-size: 2.5rem;
        }

        .card p {
            font-size: 1rem;
        }

        .card button {
            margin-top: 10px;
            font-weight: bold;
            background-color: #ffffff;
            /* Button background color */
            color: #333;
            /* Button text color */
            padding: 10px 0;
            /* Button padding */
            width: 100%;
            /* Button width matches the card width */
            border: none;
            /* No border */
            cursor: pointer;
            /* Pointer cursor */
            transition: background-color 0.3s ease;
            /* Smooth transition */
        }

        .card button:hover {
            background-color: #e0e0e0;
            /* Button hover color */
        }

        .card.blue {
            background-color: #2e5b8f;
        }

        .card.green {
            background-color: #6fbf5f;
        }

        .card.light-blue {
            background-color: #29a9e0;
        }

        /* Title Style */
        .title {
            margin-top: 20px;
            font-size: 2rem;
            font-weight: bold;
            color: #333;
        }
    </style>
</head>

<body>
    <?php
    include('header.php');
    include('sidebar.php');
    ?>

    <div class="container"><!-- Dashboard Title -->
        <h1 class="title">Dashboard</h1>

        <div class="dashboard">
            <div class="card blue">
                <?php $query = mysqli_query($con, "SELECT id FROM `blood-group`");
                $totaldg = mysqli_num_rows($query); ?>
                <h2><?php echo htmlentities($totaldg); ?></h2>
                <p>LISTED BLOOD GROUPS</p>
                <button onclick="window.location.href='manage-bloodgroup.php';">FULL DETAIL ➔</button>
            </div>
            <div class="card green">
                <?php $query = mysqli_query($con, "SELECT id FROM blooddonars");
                $totaldonars = mysqli_num_rows($query); ?>
                <h2><?php echo htmlentities($totaldonars); ?></h2>
                <p>REGISTERED BLOOD GROUP</p>
                <button onclick="window.location.href='donor-list.php';">FULL DETAIL ➔</button>
            </div>
            <div class="card light-blue">
                <?php $query = mysqli_query($con, "SELECT id FROM contactus");
                $totalcontact = mysqli_num_rows($query); ?>
                <h2><?php echo htmlentities($totalcontact); ?></h2>
                <p>TOTAL QUERIES</p>
                <button onclick="window.location.href='manage-conactusquery.php';">FULL DETAIL ➔</button>
            </div>
        </div>
    </div>
</body>

</html>