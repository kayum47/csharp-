<?php
include('includes/dbconnection.php');
if (isset($_REQUEST['submit'])) {
    $nm = $_REQUEST['name'];
    $num = $_REQUEST['number'];
    $email = $_REQUEST['email'];
    $msg = $_REQUEST['message'];

    // Correct the SQL query by removing the quotes around column names
    $sql = "INSERT INTO contactus (name, number, email, message) VALUES ('$nm', '$num', '$email', '$msg')";
    
    $query = mysqli_query($con, $sql);
    
    if ($query) {
        echo "<script>alert('Data Submit successful!');</script>";
        echo "<script>window.location.href='ContactUs.php'</script>";
        
    } else {
        echo '<script>alert("Something went wrong. Please try again")</script>';
        echo "Error: " . mysqli_error($con); // Print the actual error message
    }
}
?>
<html>
<head>
    <style>
         body {
            background-color: #f4f4f4;
            align-items: center;
        }
        .container {
            margin-top: 75px;
            margin-bottom: 20px;
            display: flex;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
            
            width: 100%;
        }

        .left {
            flex: 1;
        }

        .left img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .right {
            flex: 1;
            padding: 20px;
        }

        .h2 {
            margin-bottom: 20px;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input,
        textarea {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <?php include("header.php") ?>
    <div class="container">
        <div class="left">
            <img src="images/1.jpg" alt="Image">
        </div>
        <div class="right">
            <h2 class="h2">Contact Us</h2>
            <form id="contactForm" method="post">
                <input type="text" id="name" name="name" placeholder="Please enter your name." required>
                <input type="tel" id="number" name="number" placeholder="Please enter your phone number." required>
                <input type="email" id="email" name="email" placeholder="Please enter your email address." required>
                <textarea id="message" name="message" placeholder="Please enter your message" required></textarea>
                <button type="submit" name="submit">Send Message</button>
            </form>
        </div>
    </div>

    <?php include("footer.php") ?>
</body>
</html>
